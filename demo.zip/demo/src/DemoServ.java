import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;  
import javax.servlet.*;  

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.*;
import com.google.gson.stream.JsonReader;

import java.io.*;  
import java.net.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@WebServlet("/DemoServ")
public class DemoServ extends HttpServlet{  
	public void doPost(HttpServletRequest req,HttpServletResponse res)  
			throws ServletException,IOException  
	{  
		
		String dt = req.getParameter("date1");
		System.out.println("date : "+dt);
		
		JsonElement jelement;
	    JsonArray jarray;
	    try {
	        URL url = new URL("http://sms.hspsms.com/getDLRReport?username=Dixon&apikey=6e21d14b-3967-4e55-a174-001ca6172f55&from="+dt+"&to="+dt+"&sendername=HINDIA");
	        URLConnection connection = url.openConnection();
	        connection.setDoInput(true);
	        InputStream inStream = connection.getInputStream();
	        BufferedReader input = new BufferedReader(new InputStreamReader(inStream));

	        jelement = new JsonParser().parse(input);

	        jarray = jelement.getAsJsonArray();

	        res.setContentType("application/json");
	        PrintWriter out = res.getWriter();
	        out.print(jarray);
	       
	        JSONParser parser=new JSONParser();
	        Object obj = parser.parse(jarray.toString());
	        JSONArray jsonArray = (JSONArray) obj;
	        
	        List name = null;
	        
	        for(int i = 0; i < jarray.size(); i++){
	        	JSONObject jsonObjectRow = (JSONObject) jsonArray.get(i);
	        	name = (List) jsonObjectRow.get("records");
	        	
	        }
	        
	        JSONParser parser1=new JSONParser();
	        Object obj1 = parser.parse(name.toString());
	        JSONArray jsonArray1 = (JSONArray) obj1;
	       
	        ArrayList<String> senton = new ArrayList<String>();
	        ArrayList<String> mobile = new ArrayList<String>();
	        ArrayList<String> message = new ArrayList<String>();	  
	        ArrayList<String> status = new ArrayList<String>();	  
	        
	        for(int i = 0; i < name.size(); i++){
	        	
	        	JSONObject jsonObjectRow = (JSONObject) jsonArray1.get(i);
	        	
	        	String senton1 = (String) jsonObjectRow.get("senton");
	        	senton.add(senton1);
	        	
	        	String mobile1 = (String) jsonObjectRow.get("mobile");
	        	mobile.add(mobile1);
	        	
	        	String message1 = (String) jsonObjectRow.get("message");
	        	message.add(message1);
	        	
	        	String status1 = (String) jsonObjectRow.get("status");
	        	status.add(status1);
	        }
	        
	        req.setAttribute("senton", senton);
	        req.setAttribute("mobile", mobile);
	        req.setAttribute("message", message);
	        req.setAttribute("status", status);
	        req.setAttribute("dt", dt);
	        
	        req.getRequestDispatcher("historysms.jsp").forward(req, res);
	        
	    } catch (Exception e) {
	        e.printStackTrace();
	    } 
	}
	
}  